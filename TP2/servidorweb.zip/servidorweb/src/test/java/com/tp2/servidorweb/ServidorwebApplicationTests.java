package com.tp2.servidorweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
