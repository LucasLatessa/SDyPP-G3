package com.tp2.servidorweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServidorwebApplication.class, args);
	}

}
